document.body.style.maxWidth = "1200px";
document.querySelector("#head-menu").style.opacity = "0.1";